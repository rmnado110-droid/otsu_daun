# Pengukur Luas Daun dengan Otsu Binarization
Dataset: PlantVillage - https://github.com/spMohanty/PlantVillage-Dataset

## Menjalankan
1. Buka folder ini di VS Code (File > Open Folder) dan klik Trust.
2. Terminal (Ctrl+`):
   - Windows: `python -m venv .venv` lalu `.venv\Scripts\activate`
   - macOS/Linux: `python3 -m venv .venv` lalu `source .venv/bin/activate`
3. `pip install -r requirements.txt`
4. `streamlit run app_otsu_daun.py` (atau Ctrl+Shift+B)

Taruh foto daun dari dataset di folder `dataset/`, lalu unggah lewat sidebar.
Dua citra sintetis di `dataset/` hanya untuk uji coba cepat.
