"""
Pengukur Luas Daun & Estimasi Area Bercak dengan Otsu Binarization
Mata kuliah : Computer Vision and NLP - Segmentasi Citra (Thresholding)
Dataset     : PlantVillage (https://github.com/spMohanty/PlantVillage-Dataset)

Jalankan:  streamlit run app_otsu_daun.py
"""
import cv2
import numpy as np
import pandas as pd
import streamlit as st
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

st.set_page_config(page_title="Otsu - Luas Daun", layout="wide")

KANAL = ["Grayscale", "Saturasi (HSV)", "Hijau (G)"]


# ---------------------------------------------------------------- citra contoh
def buat_daun_contoh(n=450, bercak=True, seed=1):
    """Citra daun sintetis di latar abu-abu (hanya untuk demo bila tanpa dataset)."""
    rng = np.random.default_rng(seed)
    img = np.full((n, n, 3), (170, 172, 175), np.uint8)
    img = img.astype(np.float32) + np.linspace(-15, 15, n)[None, :, None]
    img = np.clip(img, 0, 255).astype(np.uint8)
    daun = np.zeros((n, n), np.uint8)
    cv2.ellipse(daun, (n // 2, n // 2), (int(n * .38), int(n * .22)), -35, 0, 360, 255, -1)
    img[daun > 0] = (40, 130, 55)                       # BGR hijau
    cv2.ellipse(img, (n // 2, n // 2), (int(n * .36), 3), -35, 0, 360, (70, 170, 90), -1)
    if bercak:
        for _ in range(7):
            cx, cy = rng.integers(130, n - 130, 2)
            if daun[cy, cx]:
                cv2.circle(img, (int(cx), int(cy)), int(rng.integers(8, 20)), (30, 70, 120), -1)
    img = np.clip(img.astype(np.float32) + rng.normal(0, 5, img.shape), 0, 255).astype(np.uint8)
    return img


# ---------------------------------------------------------------- inti metode
def pilih_kanal(bgr, kanal):
    if kanal == "Grayscale":
        return cv2.cvtColor(bgr, cv2.COLOR_BGR2GRAY)
    if kanal == "Saturasi (HSV)":
        return cv2.cvtColor(bgr, cv2.COLOR_BGR2HSV)[:, :, 1]
    return bgr[:, :, 1]


def segmentasi_otsu(bgr, kanal, blur_k, balik_manual, kernel_k):
    """Langkah: kanal -> blur Gaussian -> Otsu -> polaritas otomatis -> morfologi -> kontur terbesar."""
    ch = pilih_kanal(bgr, kanal)
    if blur_k > 1:
        ch = cv2.GaussianBlur(ch, (blur_k, blur_k), 0)
    t, biner = cv2.threshold(ch, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)

    # polaritas otomatis: tepi citra umumnya latar belakang
    tepi = np.concatenate([biner[0], biner[-1], biner[:, 0], biner[:, -1]])
    if tepi.mean() > 127:
        biner = cv2.bitwise_not(biner)
    if balik_manual:
        biner = cv2.bitwise_not(biner)

    k = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (kernel_k, kernel_k))
    biner = cv2.morphologyEx(biner, cv2.MORPH_OPEN, k)
    biner = cv2.morphologyEx(biner, cv2.MORPH_CLOSE, k)

    kontur, _ = cv2.findContours(biner, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    mask = np.zeros_like(biner)
    besar = None
    if kontur:
        besar = max(kontur, key=cv2.contourArea)
        cv2.drawContours(mask, [besar], -1, 255, -1)      # isi lubang
    return ch, float(t), mask, besar


def hitung_bercak(bgr, mask):
    """Piksel di dalam daun yang tidak 'hijau sehat' dianggap bercak / area tidak sehat."""
    hsv = cv2.cvtColor(bgr, cv2.COLOR_BGR2HSV)
    h, s = hsv[:, :, 0], hsv[:, :, 1]
    sehat = (h >= 30) & (h <= 90) & (s > 40)
    bercak = (mask > 0) & ~sehat
    return bercak


def ukur(mask, kontur, bercak, ppc):
    luas = int(np.count_nonzero(mask))
    n_bercak = int(np.count_nonzero(bercak))
    keliling = float(cv2.arcLength(kontur, True)) if kontur is not None else 0.0
    x, y, w, h = cv2.boundingRect(kontur) if kontur is not None else (0, 0, 0, 0)
    bulat = 4 * np.pi * luas / (keliling ** 2) if keliling > 0 else 0.0
    out = {
        "Luas daun (px)": luas,
        "Keliling (px)": round(keliling, 1),
        "Panjang x Lebar bbox (px)": f"{w} x {h}",
        "Sirkularitas": round(bulat, 3),
        "Luas bercak (px)": n_bercak,
        "Persen bercak (%)": round(100 * n_bercak / luas, 2) if luas else 0.0,
        "Persen daun dari citra (%)": round(100 * luas / mask.size, 2),
    }
    if ppc and ppc > 0:
        out["Luas daun (cm2)"] = round(luas / ppc ** 2, 2)
    return out


def overlay(bgr, kontur, bercak):
    vis = bgr.copy()
    merah = np.zeros_like(vis)
    merah[:] = (0, 0, 255)
    vis[bercak] = cv2.addWeighted(vis, 0.4, merah, 0.6, 0)[bercak]
    if kontur is not None:
        cv2.drawContours(vis, [kontur], -1, (0, 255, 0), 2)
    return vis


def histogram_fig(ch, t):
    fig, ax = plt.subplots(figsize=(5, 2.6))
    ax.hist(ch.ravel(), bins=256, range=(0, 255), color="#6b7280")
    ax.axvline(t, color="red", lw=2, label=f"T Otsu = {t:.0f}")
    ax.set_xlabel("Intensitas"); ax.set_ylabel("Jumlah piksel"); ax.legend()
    fig.tight_layout()
    return fig


def baca(file, maks):
    bgr = cv2.imdecode(np.frombuffer(file.read(), np.uint8), cv2.IMREAD_COLOR)
    if bgr is None:
        return None
    s = min(1.0, maks / max(bgr.shape[:2]))
    return cv2.resize(bgr, None, fx=s, fy=s, interpolation=cv2.INTER_AREA) if s < 1 else bgr


def png(img):
    return cv2.imencode(".png", img)[1].tobytes()


# ---------------------------------------------------------------- UI
st.title("Pengukur Luas Daun dengan Otsu Binarization")
st.caption("Dataset: PlantVillage - github.com/spMohanty/PlantVillage-Dataset")

with st.sidebar:
    st.header("Pengaturan")
    files = st.file_uploader("Unggah citra daun (bisa banyak)", type=["jpg", "jpeg", "png", "bmp"],
                             accept_multiple_files=True)
    kanal = st.selectbox("Kanal yang di-Otsu", KANAL, index=1,
                         help="Saturasi biasanya memisahkan daun berwarna dari latar abu-abu/putih.")
    blur_k = st.select_slider("Blur Gaussian (kernel)", [1, 3, 5, 7, 9], value=5)
    kernel_k = st.select_slider("Kernel morfologi", [3, 5, 7, 9, 11], value=5)
    balik = st.checkbox("Balik hasil biner (jika daun terbalik)")
    ppc = st.number_input("Kalibrasi: piksel per cm (0 = abaikan)", 0.0, 1000.0, 0.0, 1.0,
                          help="Letakkan penggaris/objek referensi untuk tahu berapa piksel = 1 cm.")
    maks = st.slider("Ukuran sisi maks (px)", 200, 1000, 500, 50)

tab1, tab2 = st.tabs(["Analisis satu citra", "Batch (banyak citra)"])

with tab1:
    if files:
        pilih = st.selectbox("Citra", [f.name for f in files])
        f = next(x for x in files if x.name == pilih)
        f.seek(0)
        bgr = baca(f, maks)
    else:
        st.info("Belum ada citra diunggah, memakai citra daun sintetis sebagai contoh.")
        bgr = buat_daun_contoh()

    if bgr is None:
        st.error("Gagal membaca citra.")
    else:
        ch, t, mask, kontur = segmentasi_otsu(bgr, kanal, blur_k, balik, kernel_k)
        bercak = hitung_bercak(bgr, mask)
        hasil = ukur(mask, kontur, bercak, ppc)
        vis = overlay(bgr, kontur, bercak)

        c = st.columns(4)
        c[0].image(cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB), caption="1. Citra asli", use_container_width=True)
        c[1].image(ch, caption=f"2. Kanal: {kanal}", use_container_width=True)
        c[2].image(mask, caption=f"3. Mask Otsu (T = {t:.0f})", use_container_width=True)
        c[3].image(cv2.cvtColor(vis, cv2.COLOR_BGR2RGB),
                   caption="4. Hasil (hijau = batas, merah = bercak)", use_container_width=True)

        a, b = st.columns([1, 1])
        a.pyplot(histogram_fig(ch, t))
        b.table(pd.DataFrame(hasil.items(), columns=["Ukuran", "Nilai"]).astype(str))
        st.download_button("Unduh citra hasil (PNG)", png(vis), "hasil_otsu.png")

with tab2:
    if not files:
        st.info("Unggah beberapa citra di sidebar untuk analisis batch.")
    else:
        baris = []
        for f in files:
            f.seek(0)
            img = baca(f, maks)
            if img is None:
                continue
            _, t, m, k = segmentasi_otsu(img, kanal, blur_k, balik, kernel_k)
            r = {"File": f.name, "T Otsu": round(t, 1)}
            r.update(ukur(m, k, hitung_bercak(img, m), ppc))
            baris.append(r)
        df = pd.DataFrame(baris)
        st.dataframe(df, use_container_width=True)
        st.download_button("Unduh tabel (CSV)", df.to_csv(index=False).encode(), "hasil_batch.csv")
